
  # Pathology Laboratory Website (Community)

  This is a code bundle for Pathology Laboratory Website (Community). The original project is available at https://www.figma.com/design/f3vpheHN3MhwK7bMcrOnGN/Pathology-Laboratory-Website--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  